from django.conf.urls import url
from . import views
from .feeds import LikedBooksFeed
from django.contrib.auth.views import login, logout

app_name = 'homepage'
urlpatterns = [
    url(r'^$', views.IndexView.as_view(), name='index'),
    url(r'^register/$', views.UserFormView.as_view(), name='register'),
    url(r'^(?P<pk>[0-9]+)/$', views.DetailView.as_view(), name='detail'),
    url(r'book/add/$', views.BookCreate.as_view(), name='book-add'),
    url(r'^(?P<pk>[0-9]+)/like/$', views.like, name='like'),
    url(r'^(?P<pk>[0-9]+)/rating/$', views.rating, name='rating'),
    url(r'^genre/(?P<gen>.*)$', views.genre, name='genre'),
    url(r'^search/$', views.search, name='search'),
    url(r'^profile/$', views.profile, name='profile'),

    url(r'^mostliked/$', LikedBooksFeed()),
    url(r'^liked/(?P<object_pk>\w+)$', views.likefeed, name='likefeed'),

    url(r'^login/$', login , {'template_name': 'homepage/login.html'}, name='login'),
    url(r'^logout/$', logout, {'template_name': 'homepage/logout.html'}, name='logout'),

]
