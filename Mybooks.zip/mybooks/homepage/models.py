from django.db import models
from django.core.urlresolvers import reverse

class book(models.Model):
    title = models.CharField(max_length=250)
    author = models.CharField(max_length=250)
    genre = models.CharField(max_length=250)
    rating = models.FloatField(default=0)
    likes = models.IntegerField(default=0)
    cover = models.CharField(max_length=500)
    no_of_ratings = models.IntegerField(default=0)
    synopsis = models.TextField(max_length=1000, default='this is the book description')

    def get_absolute_url(self):
        return reverse('homepage:detail', kwargs={'pk': self.pk})

    def __str__(self):
        return self.title





















