from django.views import generic
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from .models import book
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login
from django.views.generic import View
from .forms import UserForm
from django.http import HttpResponseRedirect
from django.urls import reverse
import re
from django.db.models import Q

class IndexView(generic.ListView):
    template_name = 'homepage/home.html'
    context_name = 'book_list'  # default : object_list
    def get_queryset(self):
        return book.objects.order_by('-likes')


class DetailView(generic.DetailView):
    model = book
    template_name = 'homepage/detail.html'


class BookCreate(CreateView):
    model = book
    fields = ['title', 'author', 'genre', 'cover']



class UserFormView(View):
    form_class = UserForm
    template_name = 'homepage/registration_form.html'

    # display blank form
    def get(self, request):
        form = self.form_class(None)
        return render(request, self.template_name, {'form': form})

    # process form data
    def post(self, request):
        form = self.form_class(request.POST)

        if form.is_valid():

            # save all the form info in an object
            user = form.save(commit=False)

            # cleaned (normalized) data
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user.set_password(password)
            user.save()
            return redirect('homepage:index')

            #returns User object if credentials are correct
            #user = authenticate(username=username, password=password)

            #if user is not None:

                #if user.is_active:
                    #login(request, user)
                    #return redirect('homepage:index')

        return render(request, self.template_name, {'form': form})





def like(request, pk):
    b = get_object_or_404(book, pk=pk)
    b.likes += 1
    b.save()
    return HttpResponseRedirect(reverse('homepage:detail', args=(b.id, )))

def rating(request, pk):
    b = get_object_or_404(book, pk=pk)
    total = b.rating * b.no_of_ratings
    total += int(request.POST['choice'])
    b.no_of_ratings += 1
    b.rating = total / b.no_of_ratings

    b.save()
    return HttpResponseRedirect(reverse('homepage:detail', args=(b.id,)))

def genre(request, gen):
    book_list = book.objects.all().filter(genre=gen)
    return render(request, 'homepage/genre.html', {'book_list': book_list, 'genre': gen, })









def normalize_query(query_string,
    findterms=re.compile(r'"([^"]+)"|(\S+)').findall,
    normspace=re.compile(r'\s{2,}').sub):

    return [normspace(' ', (t[0] or t[1]).strip()) for t in findterms(query_string)]

def get_query(query_string, search_fields):

    query = None # Query to search for every search term
    terms = normalize_query(query_string)
    for term in terms:
        or_query = None # Query to search for a given term in each field
        for field_name in search_fields:
            q = Q(**{"%s__icontains" % field_name: term})
            if or_query is None:
                or_query = q
            else:
                or_query = or_query | q
        if query is None:
            query = or_query
        else:
            query = query & or_query
    return query

def search(request):
    query_string = ''
    found_entries = None
    if ('q' in request.GET) and request.GET['q'].strip():
        query_string = request.GET['q']

        entry_query = get_query(query_string, ['title', 'author', 'genre', ])

        found_entries = book.objects.filter(entry_query)

    return render(request, 'homepage/search_results.html',
                          {'query_string': query_string, 'found_entries': found_entries, })


def likefeed(request, object_pk):
    buk = get_object_or_404(book, pk=object_pk)
    return render(request, 'homepage/detail.html', {'book': buk})

def profile(request):
    return render(request, 'homepage/profile.html',)