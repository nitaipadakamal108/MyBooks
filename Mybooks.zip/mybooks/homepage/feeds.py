from django.contrib.syndication.views import Feed
from django.urls import reverse
from .models import book

class LikedBooksFeed(Feed):
    title = 'Most Liked Books'
    link = '/mostliked/'
    description = 'Most Liked Books Currently'

    def items(self):
        return book.objects.all().order_by("-likes")[:5]

    def item_title(self, item):
        return item.title

    def item_description(self, item):
        return item.genre

    def item_link(self, item):
        return reverse('homepage:likefeed', kwargs={'object_pk': item.pk })
